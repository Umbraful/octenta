char *get_instructions_event(char *event, int size);
char *get_offcore_event(char *event, int size);
char *get_invalid_event_name(char *event, int size);
