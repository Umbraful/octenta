int _freebsd_get_memory_info( PAPI_hw_info_t *hw_info, int id);
int _papi_freebsd_get_dmem_info(PAPI_dmem_info_t *d);
 
